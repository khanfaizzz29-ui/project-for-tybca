import React, { useState, useRef, ChangeEvent } from 'react';
import { 
  Upload, 
  FileText, 
  CheckCircle2, 
  AlertCircle, 
  BarChart3, 
  BrainCircuit, 
  FileSearch, 
  GraduationCap,
  Loader2,
  ChevronRight,
  Target,
  Sparkles,
  Search,
  BookOpen
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Radar, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell
} from 'recharts';
import { cn } from './lib/utils';

interface EvaluationData {
  scores: {
    originality: number;
    technicalDepth: number;
    practicalRelevance: number;
    clarity: number;
    consistency: number;
  };
  feedback: {
    originality: string;
    technicalDepth: string;
    practicalRelevance: string;
    clarity: string;
    consistency: string;
  };
  overallScore: number;
  summary: string;
  title: string;
  author: string;
}

export default function App() {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<EvaluationData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
      setError(null);
    } else if (selectedFile) {
      setError('Please upload a valid PDF file.');
      setFile(null);
    }
  };

  const handleUpload = async () => {
    if (!file) return;

    setLoading(true);
    setError(null);
    setResult(null);

    const formData = new FormData();
    formData.append('projectReport', file);

    try {
      const response = await fetch('/api/evaluate', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || 'Evaluation failed');
      }

      const data = await response.json();
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  const chartData = result ? [
    { subject: 'Originality', A: result.scores.originality, fullMark: 10 },
    { subject: 'Tech Depth', A: result.scores.technicalDepth, fullMark: 10 },
    { subject: 'Practicality', A: result.scores.practicalRelevance, fullMark: 10 },
    { subject: 'Clarity', A: result.scores.clarity, fullMark: 10 },
    { subject: 'Consistency', A: result.scores.consistency, fullMark: 10 },
  ] : [];

  const barData = result ? [
    { name: 'Originality', score: result.scores.originality, color: '#3b82f6' },
    { name: 'Tech Depth', score: result.scores.technicalDepth, color: '#8b5cf6' },
    { name: 'Practicality', score: result.scores.practicalRelevance, color: '#06b6d4' },
    { name: 'Clarity', score: result.scores.clarity, color: '#10b981' },
    { name: 'Consistency', score: result.scores.consistency, color: '#f59e0b' },
  ] : [];

  return (
    <div className="flex h-screen bg-dark text-[#E0E0E0] font-sans overflow-hidden">
      {/* Sidebar */}
      <aside className="w-72 border-r border-white/10 flex flex-col bg-dark shrink-0">
        <div className="p-8">
          <h1 className="text-2xl font-serif italic tracking-widest text-gold border-b border-gold/30 pb-4">
            THE BLACK BOOK
          </h1>
        </div>
        
        <nav className="flex-1 px-4 space-y-2 overflow-y-auto">
          <div className="px-4 py-3 bg-white/5 border-l-2 border-gold text-gold flex justify-between items-center transition-all">
            <span className="text-[10px] uppercase tracking-widest font-bold">Project Reports</span>
            <span className="text-[10px] bg-gold text-black px-1.5 py-0.5 rounded-sm font-bold">LIVE</span>
          </div>
          <div className="px-4 py-3 text-white/40 hover:text-white/70 transition-colors flex justify-between items-center cursor-pointer group">
            <span className="text-[10px] uppercase tracking-widest font-light">Analysis Archive</span>
            <ChevronRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
          <div className="px-4 py-3 text-white/40 hover:text-white/70 transition-colors flex justify-between items-center cursor-pointer group">
            <span className="text-[10px] uppercase tracking-widest font-light">Secure Assets</span>
            <Search className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </nav>

        <div className="p-8 mt-auto">
          <div className="p-4 rounded border border-white/5 bg-white/[0.02] text-center">
            <p className="text-[10px] uppercase tracking-tighter text-white/30 mb-1">Clearance Level</p>
            <p className="text-sm font-mono text-gold">ALPHA-9 OVERSEER</p>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-20 border-b border-white/10 flex items-center justify-between px-10 shrink-0">
          <div className="flex space-x-8">
            <div className="text-[10px] uppercase tracking-[0.2em] text-gold">System: Active</div>
            <div className="text-[10px] uppercase tracking-[0.2em] text-white/40">Mode: Evaluation</div>
          </div>
          <div className="flex items-center space-x-4">
            <motion.div 
              animate={{ opacity: [1, 0.4, 1] }} 
              transition={{ repeat: Infinity, duration: 2 }}
              className="h-2 w-2 rounded-full bg-red-800 shadow-[0_0_8px_rgba(153,27,27,0.8)]"
            />
            <span className="text-[10px] font-mono tracking-widest text-white/50 uppercase">
              Encrypted Session Active
            </span>
          </div>
        </header>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto bg-dark-alt/50">
          {!result ? (
            <div className="flex flex-col items-center justify-center min-h-full p-8 max-w-4xl mx-auto space-y-12">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center space-y-4"
              >
                <h2 className="text-5xl font-serif italic text-white tracking-tight">
                  Academic Dossier <span className="text-gold">Intelligence</span>
                </h2>
                <div className="h-1 w-20 bg-gold mx-auto"></div>
                <p className="text-white/40 font-light max-w-lg mx-auto tracking-wide text-sm">
                  The automated NLP framework for analyzing the integrity, complexity, and structural alignment of academic project reports.
                </p>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                className="w-full bg-white/[0.02] border border-white/10 rounded-lg p-10 shadow-2xl space-y-8"
              >
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className={cn(
                    "border border-white/5 bg-black/40 rounded flex flex-col items-center justify-center p-16 cursor-pointer transition-all hover:bg-white/[0.02] group relative overflow-hidden",
                    file ? "border-gold/50" : "hover:border-white/20"
                  )}
                >
                  <input type="file" ref={fileInputRef} className="hidden" accept=".pdf" onChange={handleFileChange} />
                  <div className="relative z-10 flex flex-col items-center gap-4">
                    <div className={cn(
                      "w-12 h-12 rounded-full flex items-center justify-center transition-all",
                      file ? "bg-gold text-black" : "bg-white/5 text-white/20 group-hover:text-gold"
                    )}>
                      {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : file ? <CheckCircle2 className="w-6 h-6" /> : <Upload className="w-6 h-6" />}
                    </div>
                    <div className="text-center">
                      <p className="text-sm font-serif italic text-white tracking-widest">
                        {file ? file.name : "DEPOSIT PDF DOSSIER"}
                      </p>
                      <p className="text-[10px] text-white/30 uppercase tracking-[0.2em] mt-1">
                        Secure Submission Protocol
                      </p>
                    </div>
                  </div>
                </div>

                {error && (
                  <div className="p-3 bg-red-950/20 border border-red-900/30 text-red-400 text-[10px] font-mono tracking-widest uppercase flex items-center gap-2">
                    <AlertCircle className="w-3 h-3" />
                    {error}
                  </div>
                )}

                <button
                  onClick={handleUpload}
                  disabled={!file || loading}
                  className={cn(
                    "w-full py-4 text-[10px] uppercase tracking-[0.4em] font-bold transition-all border",
                    file && !loading 
                      ? "bg-gold text-black border-gold hover:bg-gold-light" 
                      : "bg-transparent border-white/10 text-white/20 cursor-not-allowed"
                  )}
                >
                  {loading ? "Decrypting & Analyzing..." : "Initiate Evaluation Pulse"}
                </button>
              </motion.div>

              <div className="grid grid-cols-3 gap-8 w-full">
                {[
                  { icon: Target, label: "Precision", val: "High Frequency" },
                  { icon: BrainCircuit, label: "Intelligence", val: "Gemini 1.5 Pro" },
                  { icon: FileSearch, label: "NLP Scope", val: "Multidimensional" }
                ].map((stat, i) => (
                  <div key={i} className="text-center space-y-1">
                    <div className="text-gold/40 flex justify-center mb-2"><stat.icon className="w-5 h-5" /></div>
                    <p className="text-[10px] uppercase tracking-widest text-white/30">{stat.label}</p>
                    <p className="text-xs font-mono text-white/60">{stat.val}</p>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              className="flex h-full"
            >
              {/* Results Sidebar Pane */}
              <div className="w-1/3 border-r border-white/10 flex flex-col bg-black/20 overflow-hidden shrink-0">
                <div className="p-6 border-b border-white/10">
                  <p className="text-[10px] text-gold uppercase tracking-widest font-bold mb-1">Investigation Profile</p>
                  <h3 className="text-xl font-serif italic text-white line-clamp-2">{result.title}</h3>
                </div>
                <div className="flex-1 overflow-y-auto p-6 space-y-6">
                  {Object.entries(result.feedback).map(([key, feedback], index) => (
                    <motion.div 
                      key={key}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="group"
                    >
                      <div className="flex justify-between items-baseline mb-2">
                        <p className="text-[10px] text-white/30 uppercase tracking-widest">{key.replace(/([A-Z])/g, ' $1').trim()}</p>
                        <p className="text-[10px] font-mono text-gold">{(result.scores as any)[key].toFixed(1)}/10</p>
                      </div>
                      <div className="relative h-1 bg-white/5 rounded-full overflow-hidden mb-3">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${(result.scores as any)[key] * 10}%` }}
                          className="absolute inset-y-0 left-0 bg-gold/60"
                        />
                      </div>
                      <p className="text-[11px] leading-relaxed text-white/50 font-light italic border-l border-white/10 pl-3">
                        "{feedback}"
                      </p>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Detail Pane */}
              <div className="flex-1 p-12 bg-dark relative overflow-y-auto">
                <div className="absolute top-0 right-0 p-12 text-[120px] font-serif text-white/[0.02] pointer-events-none select-none">
                  {result.overallScore.toFixed(0)}
                </div>

                <div className="max-w-3xl space-y-12">
                  <header>
                    <div className="flex justify-between items-end mb-4">
                      <div>
                        <h2 className="text-5xl font-serif italic text-white mb-2">{result.author || "Unidentified Author"}</h2>
                        <div className="h-1 w-20 bg-gold"></div>
                      </div>
                      <div className="text-right">
                        <p className="text-[10px] uppercase tracking-widest text-white/30 mb-1">Final Metric</p>
                        <p className="text-4xl font-mono text-gold">{result.overallScore.toFixed(1)}</p>
                      </div>
                    </div>
                  </header>

                  <section className="grid grid-cols-2 gap-12">
                    <div className="bg-white/[0.02] border border-white/5 p-6 rounded relative h-[350px]">
                      <p className="text-[10px] uppercase tracking-widest text-white/30 mb-6 flex items-center gap-2">
                        <Target className="w-3 h-3 text-gold" /> Radar Verification
                      </p>
                      <ResponsiveContainer width="100%" height="90%">
                        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={chartData}>
                          <PolarGrid stroke="rgba(255,255,255,0.05)" />
                          <PolarAngleAxis dataKey="subject" tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 9 }} />
                          <PolarRadiusAxis angle={30} domain={[0, 10]} hide />
                          <Radar name="Score" dataKey="A" stroke="#C5A059" fill="#C5A059" fillOpacity={0.4} />
                        </RadarChart>
                      </ResponsiveContainer>
                    </div>

                    <div className="space-y-8">
                      <div>
                        <p className="text-[10px] uppercase tracking-widest text-[#C5A059] mb-4 flex items-center gap-2">
                          <Sparkles className="w-3 h-3" /> Intelligence Summary
                        </p>
                        <p className="text-sm leading-relaxed text-white/70 font-light italic border-l border-[#C5A059]/30 pl-6">
                          {result.summary}
                        </p>
                      </div>

                      <div className="pt-6 grid grid-cols-2 gap-4">
                        <button 
                          onClick={() => {
                            setResult(null);
                            setFile(null);
                          }}
                          className="px-6 py-3 bg-white/5 border border-white/10 text-white/60 text-[10px] uppercase tracking-widest font-bold hover:bg-white/10 transition-all"
                        >
                          New Intelligence
                        </button>
                        <button className="px-6 py-3 bg-gold text-black text-[10px] uppercase tracking-widest font-bold hover:bg-gold-light transition-all">
                          Export Dossier
                        </button>
                      </div>
                    </div>
                  </section>

                  <section className="bg-white/[0.01] border-y border-white/5 p-8 -mx-8">
                    <p className="text-[10px] uppercase tracking-[0.3em] text-white/30 mb-6">Internal Comparison Vectors</p>
                    <div className="h-64 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={barData}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                          <XAxis dataKey="name" tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 10 }} />
                          <YAxis hide domain={[0, 10]} />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#0A0A0B', border: '1px solid rgba(255,255,255,0.1)', color: '#C5A059' }}
                            itemStyle={{ color: '#C5A059' }}
                          />
                          <Bar dataKey="score" radius={[2, 2, 0, 0]}>
                            {barData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} fillOpacity={0.8} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </section>
                </div>
              </div>
            </motion.div>
          )}
        </div>

        {/* Info Bar / Footer */}
        <footer className="h-12 border-t border-white/10 bg-black flex items-center px-10 justify-between text-[10px] tracking-[0.3em] text-white/20 shrink-0">
          <div className="uppercase">© 2024 Project Quality Intelligence // Beta v0.9</div>
          <div className="uppercase">Clearance: Level 9 Overseer // Status: Secure</div>
        </footer>
      </main>
    </div>
  );
}

